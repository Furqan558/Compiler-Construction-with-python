file=open("table.txt", "r")
lines=file.readlines()
file.close()
data=[]
parser_table=[]
#print(lines)
for i in lines:
    data.append(i.replace("\n","").replace("Â\xa0","?"))
for i in data:
    parser_table.append(i.split("\t"))
symbols=parser_table.pop(0)
print("symbols : ",symbols)
print(parser_table)

file=open("production.txt","r")
lines=file.readlines()
file.close()
righthand_production=[]
lefthand_production=[]
for x in lines:
    id=x.index("->")
    temp=x[:id]
    lefthand_production.append(temp)
    temp=x[id+2:]
    temp=temp.replace('\n','')
    temp=temp.strip()
    righthand_production.append(temp)
print("lefthand_productions : ",lefthand_production)
print("righthand_productions : ",righthand_production)

ip="ysmtghrtmhu$"
current_index_input=0
stackk=[]
stackk.append(0)

while(True):

    print("stack : ",stackk)
    row=stackk[-1]
    col=symbols.index(ip[current_index_input])
    print("row : ",row," column : ",col)
    value=parser_table[row][col]
    print(value)

    if "S" in value:
        state_number=int(value[1])
        stackk.append(ip[current_index_input])
        stackk.append(state_number)
        current_index_input=current_index_input+1

    elif "R" in value:
        reduction_number=int(value[1])
        rhs_len=len(righthand_production[reduction_number])
        rhs_len*=2
        for x in range(rhs_len):
            stackk.pop()
        stackk.append(lefthand_production[reduction_number])
        row=stackk[-2] 
        #x=symbols.index("R")
        col=symbols.index(stackk[-1])
        value=int(parser_table[row][col])
        stackk.append(value)  

    elif "A" in value :
        if ip[current_index_input]=='$':
            print("\n_________parsing successful_________\n")
            break
        else:
            print("\n_________string rejected_________\n")
            break
        
    elif "?" in value :
        print("________Parsing Failed_________")
        break
