lis = [1, 2, 3, 4, 5]
sum = 0
for i in lis:
    sum = sum+i
print(sum)
