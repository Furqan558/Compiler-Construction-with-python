
dict1 = {"windows": 13, "linux": 3, "unix": 6, "android": 11}
list1 = sorted(dict1.values())
largest_3 = list1[-3]
print("Second largest element found = ", largest_3)
