lis = [1, 2, 3, 4, 5]
product = 1
for i in lis:
    product = product*i
print(product)
